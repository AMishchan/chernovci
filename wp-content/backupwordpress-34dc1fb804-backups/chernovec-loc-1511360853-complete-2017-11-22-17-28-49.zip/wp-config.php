<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'chernovec');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'i=J%T2Ov|PJ@a({^pU]ZeG@7%&YtB79G_+90k`2E16q,PUFbL1Oft#bK`yi#cw/{');
define('SECURE_AUTH_KEY',  'Od,GjBwI5>MyJSnho<( >._OiJgAw)@GzZgJwycBC>.JB9 0a}=[9uxpnrWu# qG');
define('LOGGED_IN_KEY',    '|gEOC<j<UAB{gDYFR)6A(LN+)*r;8y/2K8j5EE3E#}$|rh8iKGVp;#X~*V6B&,qG');
define('NONCE_KEY',        '%k-MzK$c]ioV[6F!6A& a[c@_JH Otz$];;6Q0q9>]4YB7Y~PfL&i6[&*TR$}fx2');
define('AUTH_SALT',        'Q_N2WE}ylaO?R##P`Cs!fCwHBLR:h@ikb,*$:9M;b]2qO.o}AE,P#!d^%}f+5T0^');
define('SECURE_AUTH_SALT', 'U#=9m+qyC)E|V3,KjYgB4E}klIP_/rkI@2[R?TKO^2M|1]]>{3eA!@(53axx9Ga.');
define('LOGGED_IN_SALT',   '&Gl9Az-Qul:(l/,s6wU@jN|P~hrO-O?TM)scpjm78UVE7%]$HY3Vr4 EugVLp@DN');
define('NONCE_SALT',       '~cEF^=3Fs7bZh$*HtRw I+7.Og2wPG?Q*7?G8BcG3*WN1e(3n;vas)>,;vRoLyqX');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
